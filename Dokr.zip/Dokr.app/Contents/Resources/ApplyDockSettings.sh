#!/bin/zsh
set -euo pipefail

domain="com.apple.dock"
mode="${1:-}"

read_preference() {
    local key="$1"
    local fallback="$2"
    local value
    value=$(/usr/bin/defaults read "$domain" "$key" 2>/dev/null) || value="$fallback"
    print -r -- "$value"
}

read_boolean() {
    local value
    value=$(read_preference "$1" "$2")
    case "$value" in
        1|true|TRUE|YES|yes) print -r -- "true" ;;
        *) print -r -- "false" ;;
    esac
}

if [[ "$mode" == "--read" ]]; then
    speed=$(read_preference "autohide-time-modifier" "0.5")
    dim_hidden=$(read_boolean "showhidden" "0")
    show_dots=$(read_boolean "show-process-indicators" "1")
    autohide=$(read_boolean "autohide" "0")
    position=$(read_preference "orientation" "bottom")
    scroll_to_open=$(read_boolean "scroll-to-open" "0")
    minimize_effect=$(read_preference "mineffect" "genie")
    show_only_running=$(read_boolean "static-only" "0")

    print -r -- "speed=$speed"
    print -r -- "dimHidden=$dim_hidden"
    print -r -- "showDots=$show_dots"
    print -r -- "autohide=$autohide"
    print -r -- "position=$position"
    print -r -- "scrollToOpen=$scroll_to_open"
    print -r -- "minimizeEffect=$minimize_effect"
    print -r -- "showOnlyRunning=$show_only_running"
    exit 0
fi

if [[ "$mode" == "--restart" ]]; then
    /usr/bin/killall Dock
    exit 0
fi

if [[ "$mode" == "--reset" ]]; then
    /usr/bin/defaults delete "$domain" autohide-time-modifier 2>/dev/null || true
    /usr/bin/defaults delete "$domain" showhidden 2>/dev/null || true
    /usr/bin/defaults delete "$domain" show-process-indicators 2>/dev/null || true
    /usr/bin/defaults delete "$domain" autohide 2>/dev/null || true
    /usr/bin/defaults delete "$domain" orientation 2>/dev/null || true
    /usr/bin/defaults delete "$domain" scroll-to-open 2>/dev/null || true
    /usr/bin/defaults delete "$domain" mineffect 2>/dev/null || true
    /usr/bin/defaults delete "$domain" static-only 2>/dev/null || true
    /usr/bin/killall Dock
    exit 0
fi

speed="${1:-}"
dim_hidden="${2:-}"
show_dots="${3:-}"
position="${4:-}"
autohide="${5:-}"
scroll_to_open="${6:-}"
minimize_effect="${7:-}"
show_only_running="${8:-}"

if [[ ! "$speed" =~ '^[0-9]+([.][0-9]+)?$' ]]; then
    print -u2 "Invalid Dock animation speed."
    exit 2
fi

if [[ "$dim_hidden" != "true" && "$dim_hidden" != "false" ]]; then
    print -u2 "Invalid hidden app setting."
    exit 2
fi

if [[ "$show_dots" != "true" && "$show_dots" != "false" ]]; then
    print -u2 "Invalid app indicator setting."
    exit 2
fi

if [[ "$position" != "left" && "$position" != "bottom" && "$position" != "right" ]]; then
    print -u2 "Invalid Dock position."
    exit 2
fi

if [[ "$autohide" != "true" && "$autohide" != "false" ]]; then
    print -u2 "Invalid automatic hide setting."
    exit 2
fi

if [[ "$scroll_to_open" != "true" && "$scroll_to_open" != "false" ]]; then
    print -u2 "Invalid scroll-to-open setting."
    exit 2
fi

if [[ "$minimize_effect" != "genie" && "$minimize_effect" != "scale" && "$minimize_effect" != "suck" ]]; then
    print -u2 "Invalid Dock minimize effect."
    exit 2
fi

if [[ "$show_only_running" != "true" && "$show_only_running" != "false" ]]; then
    print -u2 "Invalid running-apps-only setting."
    exit 2
fi

/usr/bin/defaults write "$domain" autohide-time-modifier -float "$speed"
/usr/bin/defaults write "$domain" showhidden -bool "$dim_hidden"
/usr/bin/defaults write "$domain" show-process-indicators -bool "$show_dots"
/usr/bin/defaults write "$domain" orientation -string "$position"
/usr/bin/defaults write "$domain" autohide -bool "$autohide"
/usr/bin/defaults write "$domain" scroll-to-open -bool "$scroll_to_open"
/usr/bin/defaults write "$domain" mineffect -string "$minimize_effect"
/usr/bin/defaults write "$domain" static-only -bool "$show_only_running"
/usr/bin/killall Dock
